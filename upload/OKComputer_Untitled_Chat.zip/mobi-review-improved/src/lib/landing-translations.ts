import { t } from '@/lib/i18n';
import type { Lang } from '@/lib/i18n';

export const landingTranslations = {
  en: {
    hero: {
      badge: 'AI Powered',
      version: 'v2.0',
      ctaPrimary: 'Analyze Furniture',
      ctaSecondary: 'See How It Works',
      trustPrivate: 'Private & Secure',
      trustUnits: 'Metric + Imperial',
      trustAi: 'AI-Powered',
    },
    howItWorks: {
      title: 'How It Works',
      subtitle: 'From photo to professional spec sheet in four simple steps.',
      step1Title: 'Upload Photo',
      step1Desc: 'Drag & drop or click to upload any furniture image. JPG, PNG, WebP supported.',
      step2Title: 'AI Analysis',
      step2Desc: 'Our AI identifies the furniture type, materials, dimensions, and finishes automatically.',
      step3Title: 'Review & Edit',
      step3Desc: 'Fine-tune the extracted specifications. Adjust dimensions, materials, and brand details.',
      step4Title: 'Generate PDFs',
      step4Desc: 'Download professional spec sheets with technical drawings in metric and imperial units.',
    },
    samples: {
      badge: 'Try Without Uploading',
      title: 'Example Furniture Specs',
      subtitle: 'Click on any example to load pre-filled data and see how the spec sheets look.',
      cta: 'Load Spec',
    },
    uploadSection: {
      badge: 'Start Your Analysis',
      title: 'Upload Your',
      titleHighlight: 'Furniture Photo',
    },
    analyzing: {
      imageLabel: 'Analyzing...',
      progress: 'Progress',
      estimatedTime: 'Usually completes in 10-30 seconds',
    },
    complete: {
      noPdfTitle: 'No PDFs Generated',
      noPdfDesc: 'There was an issue generating your PDFs. Please go back and try again.',
    },
  },
  es: {
    hero: {
      badge: 'Con IA',
      version: 'v2.0',
      ctaPrimary: 'Analizar Mobiliario',
      ctaSecondary: 'Ver Cómo Funciona',
      trustPrivate: 'Privado y Seguro',
      trustUnits: 'Métrico + Imperial',
      trustAi: 'Impulsado por IA',
    },
    howItWorks: {
      title: 'Cómo Funciona',
      subtitle: 'De foto a ficha profesional en cuatro simples pasos.',
      step1Title: 'Sube una Foto',
      step1Desc: 'Arrastra o haz clic para subir cualquier imagen de mobiliario. JPG, PNG, WebP compatibles.',
      step2Title: 'Análisis IA',
      step2Desc: 'Nuestra IA identifica el tipo de mobiliario, materiales, dimensiones y acabados automáticamente.',
      step3Title: 'Revisa y Edita',
      step3Desc: 'Ajusta las especificaciones extraídas. Modifica dimensiones, materiales y detalles de marca.',
      step4Title: 'Genera PDFs',
      step4Desc: 'Descarga fichas profesionales con planimetrías técnicas en unidades métricas e imperiales.',
    },
    samples: {
      badge: 'Prueba Sin Subir Imagen',
      title: 'Ejemplos de Fichas',
      subtitle: 'Haz clic en cualquier ejemplo para cargar datos prellenados y ver cómo se ven las fichas.',
      cta: 'Cargar Ficha',
    },
    uploadSection: {
      badge: 'Comienza Tu Análisis',
      title: 'Sube Tu',
      titleHighlight: 'Foto de Mobiliario',
    },
    analyzing: {
      imageLabel: 'Analizando...',
      progress: 'Progreso',
      estimatedTime: 'Usualmente completa en 10-30 segundos',
    },
    complete: {
      noPdfTitle: 'No se Generaron PDFs',
      noPdfDesc: 'Hubo un problema al generar los PDFs. Por favor regresa e intenta de nuevo.',
    },
  },
} as const;
