'use client';

import React from 'react';
import { t, type Lang } from '@/lib/i18n';
import { Eye, Ruler, FileText, Shield, Zap, Globe } from 'lucide-react';

interface FeatureCardsProps {
  lang: Lang;
}

const features = [
  {
    icon: Eye,
    titleKey: 'features.aiVision',
    descKey: 'features.smartExtraction',
    color: 'text-blue-600',
    bg: 'bg-blue-50',
    border: 'border-blue-100',
  },
  {
    icon: Ruler,
    titleKey: 'features.dualUnits',
    descKey: 'features.metricImperial',
    color: 'text-emerald-600',
    bg: 'bg-emerald-50',
    border: 'border-emerald-100',
  },
  {
    icon: FileText,
    titleKey: 'features.proPdfs',
    descKey: 'features.printReadySpecs',
    color: 'text-amber-600',
    bg: 'bg-amber-50',
    border: 'border-amber-100',
  },
  {
    icon: Shield,
    titleKey: 'features.aiVision',
    descKey: 'features.smartExtraction',
    color: 'text-purple-600',
    bg: 'bg-purple-50',
    border: 'border-purple-100',
    customTitle: lang => lang === 'en' ? 'Private & Secure' : 'Privado y Seguro',
    customDesc: lang => lang === 'en' ? 'All processing happens in your browser and on secure servers' : 'Todo el procesamiento ocurre en tu navegador y servidores seguros',
  },
  {
    icon: Zap,
    titleKey: 'features.aiVision',
    descKey: 'features.smartExtraction',
    color: 'text-rose-600',
    bg: 'bg-rose-50',
    border: 'border-rose-100',
    customTitle: lang => lang === 'en' ? 'Fast Processing' : 'Procesamiento Rápido',
    customDesc: lang => lang === 'en' ? 'AI analysis completes in under 30 seconds' : 'Análisis IA completo en menos de 30 segundos',
  },
  {
    icon: Globe,
    titleKey: 'features.aiVision',
    descKey: 'features.smartExtraction',
    color: 'text-cyan-600',
    bg: 'bg-cyan-50',
    border: 'border-cyan-100',
    customTitle: lang => lang === 'en' ? 'Bilingual' : 'Bilingüe',
    customDesc: lang => lang === 'en' ? 'Full support for English and Spanish' : 'Soporte completo en inglés y español',
  },
] as const;

export function FeatureCards({ lang }: FeatureCardsProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-8">
      {features.map((feature, index) => {
        const title = feature.customTitle
          ? feature.customTitle(lang)
          : t(lang, feature.titleKey);
        const desc = feature.customDesc
          ? feature.customDesc(lang)
          : t(lang, feature.descKey);

        return (
          <div
            key={index}
            className={`group flex flex-col items-center text-center p-4 rounded-xl bg-white border ${feature.border} hover:shadow-md hover:shadow-stone-100 transition-all duration-300 hover:-translate-y-0.5`}
          >
            <div className={`w-11 h-11 rounded-xl ${feature.bg} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300`}>
              <feature.icon className={`w-5 h-5 ${feature.color}`} />
            </div>
            <h3 className="text-sm font-semibold text-stone-800 mb-0.5">{title}</h3>
            <p className="text-xs text-stone-500 leading-relaxed">{desc}</p>
          </div>
        );
      })}
    </div>
  );
}
