# Audit de Dependencias — MOBI

## Dependencias Identificadas como SIN USO (recomendado remover)

Basado en el análisis del código fuente, las siguientes dependencias NO se utilizan actualmente en la aplicación y pueden removerse para reducir el tamaño del bundle y simplificar el mantenimiento:

### Radix UI Components (instalados pero no importados)
- `@radix-ui/react-accordion` — No hay acordeones en la UI
- `@radix-ui/react-alert-dialog` — No hay diálogos de alerta
- `@radix-ui/react-aspect-ratio` — No se usa aspect ratio
- `@radix-ui/react-avatar` — No hay avatares de usuario
- `@radix-ui/react-checkbox` — No checkboxes en los formularios actuales
- `@radix-ui/react-collapsible` — No componentes colapsables
- `@radix-ui/react-context-menu` — No menús contextuales
- `@radix-ui/react-dropdown-menu` — No dropdowns (usa botones simples)
- `@radix-ui/react-hover-card` — No hover cards
- `@radix-ui/react-menubar` — No menú bar
- `@radix-ui/react-navigation-menu` — No navegación compleja
- `@radix-ui/react-progress` — No barras de progreso lineales
- `@radix-ui/react-radio-group` — No radio groups
- `@radix-ui/react-scroll-area` — No áreas de scroll custom
- `@radix-ui/react-separator` — No separadores visuales dedicados
- `@radix-ui/react-slider` — No sliders
- `@radix-ui/react-switch` — No switches/toggles
- `@radix-ui/react-tabs` — No tabs (la UI usa estados simples)
- `@radix-ui/react-toggle` — No toggles individuales
- `@radix-ui/react-toggle-group` — No toggle groups

**NOTA:** Los shadcn/ui components pueden tener estas dependencias como peer dependencies. Si los removes, verifica que los componentes shadcn/ui que SÍ usas no dependan de ellos indirectamente.

### Otras dependencias sin uso
- `@mdxeditor/editor` — No hay editor MDX en la app
- `@tanstack/react-table` — No hay tablas de datos
- `embla-carousel-react` — No hay carruseles
- `input-otp` — No hay inputs OTP
- `react-day-picker` — No hay selección de fechas
- `react-resizable-panels` — No hay paneles redimensionables
- `react-syntax-highlighter` — No hay bloques de código
- `recharts` — No hay gráficos/charts
- `qrcode` — No se generan QR codes en el flujo principal
- `vaul` — No hay drawers/bottom sheets
- `date-fns` — Usado indirectamente? Verificar

## Dependencias que SÍ se utilizan (mantener)

### Core
- `next`, `react`, `react-dom` — Framework
- `typescript` — Tipado
- `tailwindcss`, `@tailwindcss/postcss`, `tw-animate-css` — Estilos

### UI / shadcn
- `@radix-ui/react-dialog` — Modal/preview de PDFs
- `@radix-ui/react-label` — Formularios
- `@radix-ui/react-popover` — Popovers de UI
- `@radix-ui/react-select` — Selectores de categoría
- `@radix-ui/react-slot` — Base de shadcn
- `@radix-ui/react-toast` — Notificaciones
- `@radix-ui/react-tooltip` — Tooltips
- `class-variance-authority`, `clsx`, `tailwind-merge` — Utilidades CSS
- `cmdk` — Command palette (puede usarse en shadcn)
- `lucide-react` — Iconos

### Estado y Formularios
- `zustand` — Estado global
- `react-hook-form` — Formularios de edición
- `@hookform/resolvers` — Validación formularios
- `zod` — Schema validation

### Utilidades
- `next-intl` — i18n
- `next-themes` — Tema claro/oscuro
- `next-auth` — Autenticación (instalado pero ¿sin uso visible?)
- `sonner` — Toast notifications
- `pdfkit` — Generación de PDFs
- `prisma`, `@prisma/client` — ORM
- `uuid` — IDs únicos

### AI / SDK
- `z-ai-web-dev-sdk` — SDK de IA

## Acciones Recomendadas

### 1. Audit manual con eslint
```bash
npx depcheck
```

### 2. Remover paquetes no usados
```bash
npm uninstall @radix-ui/react-accordion @radix-ui/react-alert-dialog @radix-ui/react-aspect-ratio @radix-ui/react-avatar @radix-ui/react-checkbox @radix-ui/react-collapsible @radix-ui/react-context-menu @radix-ui/react-dropdown-menu @radix-ui/react-hover-card @radix-ui/react-menubar @radix-ui/react-navigation-menu @radix-ui/react-progress @radix-ui/react-radio-group @radix-ui/react-scroll-area @radix-ui/react-separator @radix-ui/react-slider @radix-ui/react-switch @radix-ui/react-tabs @radix-ui/react-toggle @radix-ui/react-toggle-group

npm uninstall @mdxeditor/editor @tanstack/react-table embla-carousel-react input-otp react-day-picker react-resizable-panels react-syntax-highlighter recharts qrcode vaul
```

### 3. Revisar next-auth
Si la autenticación no se usa en el flujo actual, considerar:
- Implementar login básico para guardar catálogos en la nube
- O remover si no hay plan inmediato: `npm uninstall next-auth`

### 4. Verificar date-fns
```bash
grep -r "date-fns" src/ --include="*.ts" --include="*.tsx"
```
Si no hay imports directos, puede ser dependencia transitiva.

## Estimación de Reducción de Bundle

Removiendo las dependencias listadas, se estima una reducción de:
- **~40-60% menos dependencias npm**
- **~20-30% reducción en bundle size**
- **Tiempos de build más rápidos**
- **Menor superficie de ataque de seguridad**

---

**Nota:** Este es un análisis basado en lectura estática del código. Antes de remover, ejecutar `npm run build` después de cada grupo de cambios para verificar que no hay errores.
