# MOBI — Generador de Fichas de Mobiliario con IA

**MOBI** es una aplicación web profesional para diseñadores de interiores que genera automáticamente fichas de especificación técnica de mobiliario a partir de una fotografía, utilizando inteligencia artificial.

![Deploy](https://img.shields.io/badge/deploy-Vercel-black?logo=vercel)
![Stack](https://img.shields.io/badge/stack-Next.js%2016%20%7C%20React%2019%20%7C%20TypeScript%20%7C%20Tailwind%20CSS-blue)
![AI](https://img.shields.io/badge/AI-Gemini%20%7C%20Groq%20%7C%20OpenRouter-orange)

---

## ✨ Funcionalidades

- **Visión IA** — Analiza fotos de mobiliario y extrae especificaciones automáticamente
- **Unidades Duales** — Dimensiones simultáneas en métrico e imperial
- **Planimetrías Técnicas** — Dibujos profesionales en 4 vistas: frontal, lateral, planta e isométrica
- **PDFs Pro** — Fichas de especificación listas para imprimir
- **Catálogo Multi-pieza** — Acumula artículos y genera catálogos combinados
- **Editor de Especificaciones** — Revisa y modifica los datos extraídos por IA
- **Multilenguaje** — Soporte completo en inglés y español

## 🏗️ Arquitectura

```
mobi/
├── src/
│   ├── app/              # Next.js App Router (páginas y API routes)
│   │   ├── api/
│   │   │   ├── analyze/         # POST: Análisis IA de imagen
│   │   │   ├── generate-pdf/    # POST: Generación de PDFs
│   │   │   └── generate-drawing/# POST: Dibujo técnico con IA
│   │   ├── layout.tsx
│   │   ├── page.tsx             # Página principal con estados
│   │   └── globals.css
│   ├── components/
│   │   ├── layout/AppHeader.tsx
│   │   ├── upload/
│   │   │   ├── UploadZone.tsx      # Zona de drag & drop
│   │   │   └── FeatureCards.tsx    # Cards de características
│   │   ├── analyzing/AnalyzingView.tsx
│   │   ├── editing/               # Formularios de edición
│   │   │   ├── EditingView.tsx
│   │   │   ├── BrandInfoCard.tsx
│   │   │   ├── DimensionsCard.tsx
│   │   │   ├── MaterialsCard.tsx
│   │   │   ├── ProductDetailsCard.tsx
│   │   │   ├── ColorFinishesCard.tsx
│   │   │   ├── LoungeConfigsCard.tsx
│   │   │   └── TagsCard.tsx
│   │   ├── generating/GeneratingView.tsx
│   │   ├── complete/CompleteView.tsx
│   │   └── ui/                    # shadcn/ui components
│   ├── hooks/
│   │   ├── use-analysis.ts        # Lógica de análisis IA
│   │   ├── use-image-upload.ts    # Manejo de imágenes
│   │   ├── use-pdf-generation.ts  # Generación de PDFs
│   │   ├── use-catalog.ts         # Catálogo multi-pieza
│   │   ├── use-dimensions.tsx     # Inputs de dimensiones
│   │   ├── use-language.ts        # Toggle ES/EN
│   │   ├── use-mobile.ts          # Detección móvil
│   │   └── use-toast.ts           # Notificaciones toast
│   ├── lib/
│   │   ├── pdf/                   # Motor de dibujo técnico
│   │   │   ├── drawing-views.ts       # Vistas 2D/3D (ISO)
│   │   │   ├── page-generator.ts      # Generador de páginas PDF
│   │   │   ├── blueprint-renderer.ts  # Renderizado blueprint
│   │   │   ├── drawing-utils.ts       # Utilidades SVG
│   │   │   ├── drawing-hatch.ts       # Patrones de sombreado
│   │   │   ├── labels.ts              # Etiquetas i18n
│   │   │   └── types.ts               # Tipos de dibujo
│   │   ├── types.ts               # Tipos compartidos
│   │   ├── convert.ts             # Conversiones métrico/imperial
│   │   ├── i18n.ts                # Sistema de traducciones
│   │   ├── translations.ts        # Diccionarios ES/EN
│   │   ├── utils.ts               # Utilidades
│   │   └── db.ts                  # Conexión Prisma
│   └── store/
│       └── app-store.ts           # Estado global (Zustand + persist)
├── prisma/                # Esquema de base de datos
├── mobi/                  # Scripts de dibujo técnico (Python)
├── mini-services/         # Microservicios de soporte
├── db/                    # Configuración de base de datos
├── upload/                # Servicio de upload
├── download/              # Servicio de download
├── public/                # Assets estáticos
└── skills/                # Skills de IA configurables
```

## 🚀 Setup Local

### Requisitos
- Node.js 20+
- Bun o npm
- Cuenta en un proveedor de IA (Gemini, Groq u OpenRouter)

### Instalación

```bash
# 1. Clonar repositorio
git clone https://github.com/yecos/mobi.git
cd mobi

# 2. Instalar dependencias
bun install
# o: npm install

# 3. Configurar variables de entorno
cp .env.example .env.local
```

### Variables de entorno

Edita `.env.local`:

```env
# Base de datos (opcional para desarrollo local de frontend)
DATABASE_URL="postgresql://..."

# Proveedores de IA (al menos uno requerido)
Z_AI_GOOGLE_API_KEY="sk-..."        # Gemini / Google AI Studio
Z_AI_GROQ_API_KEY="gsk_..."         # Groq
Z_AI_OPENROUTER_API_KEY="sk-..."    # OpenRouter

# Prisma (producción)
PRISMA_CLIENT_ENGINE_TYPE="library"
```

### Desarrollo

```bash
# Servidor de desarrollo
bun run dev
# o: npm run dev

# Build de producción
bun run build
# o: npm run build
```

### Base de datos

```bash
# Push schema a la base de datos
bun run db:push

# Generar cliente Prisma
bun run db:generate
```

## 📦 Deploy en Vercel

1. Importa el repositorio en [Vercel](https://vercel.com)
2. Configura las variables de entorno en Settings > Environment Variables
3. Obtén una API key gratuita en:
   - [Google AI Studio](https://aistudio.google.com/apikey) (Gemini)
   - [Groq Console](https://console.groq.com)
   - [OpenRouter](https://openrouter.ai)
4. Redeploy

## 🎨 Planimetrías Técnicas

El motor de dibujo técnico implementa estándares ISO:

- **Pesos de línea**: visible (1.2pt), oculta (0.5pt dashed), centro (0.3pt), dimensión (0.5pt)
- **Patrones de sombreado**: madera diagonal, tela punteado, metal cruzado
- **Proyección isométrica**: matemáticamente correcta (30°)
- **4 vistas**: Frontal, lateral, planta e isométrica 3D
- **Detalles de tapicería**: Líneas de costura, cojines, respaldos

## 🛠️ Tech Stack

| Capa | Tecnología |
|------|-----------|
| Framework | Next.js 16.1.1 (App Router) |
| Frontend | React 19 + TypeScript |
| Estilos | Tailwind CSS v4 + shadcn/ui |
| Estado | Zustand (con persistencia local) |
| Base de datos | Prisma ORM |
| Autenticación | NextAuth v4 |
| i18n | next-intl |
| PDFs | pdfkit |
| AI SDK | z-ai-web-dev-sdk |

## 📁 Assets

Las imágenes de muestra (`page1_img1.png`, `page1_img2.jpg`) deben moverse a la carpeta `public/` para servirse como assets estáticos:

```bash
mv page1_img*.png public/
```

## 🔍 Scripts útiles

| Script | Descripción |
|--------|-------------|
| `dev` | Servidor de desarrollo con log |
| `build` | Build de producción |
| `lint` | ESLint |
| `db:push` | Push schema a DB |
| `db:generate` | Generar cliente Prisma |
| `db:migrate` | Crear migración |

## 📝 Notas de desarrollo

- La app utiliza el **App Router** de Next.js. Las API routes están en `src/app/api/`
- El estado global se maneja con **Zustand** y se persiste parcialmente (solo idioma)
- La compresión de imágenes es **client-side** para evitar timeouts en Vercel
- Los PDFs se generan **server-side** con pdfkit, incluyendo planimetrías SVG
- Las planimetrías usan proyección isométrica con cálculos trigonométricos exactos

## 📄 Licencia

MIT — Yecos

---

**Live Demo:** [mobi-vert-tau.vercel.app](https://mobi-vert-tau.vercel.app)
