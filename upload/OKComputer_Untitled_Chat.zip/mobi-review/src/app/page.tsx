'use client';

import React from 'react';
import { useAppStore } from '@/store/app-store';
import { t } from '@/lib/i18n';
import { useLanguage } from '@/hooks/use-language';
import { useImageUpload } from '@/hooks/use-image-upload';
import { useAnalysis } from '@/hooks/use-analysis';
import { usePdfGeneration } from '@/hooks/use-pdf-generation';
import { useCatalog } from '@/hooks/use-catalog';
import { useDimensions } from '@/hooks/use-dimensions';
import { AppHeader } from '@/components/layout/AppHeader';
import { UploadZone } from '@/components/upload/UploadZone';
import { FeatureCards } from '@/components/upload/FeatureCards';
import { AnalyzingView } from '@/components/analyzing/AnalyzingView';
import { GeneratingView } from '@/components/generating/GeneratingView';
import { EditingView } from '@/components/editing/EditingView';
import { CompleteView } from '@/components/complete/CompleteView';
import { CheckCircle2, FileText, Plus, RotateCcw, Layers } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function Home() {
  // Store
  const appState = useAppStore((s) => s.appState);
  const imagePreview = useAppStore((s) => s.imagePreview);
  const imageFile = useAppStore((s) => s.imageFile);
  const dragActive = useAppStore((s) => s.dragActive);
  const analysisMessages = useAppStore((s) => s.analysisMessages);
  const furnitureData = useAppStore((s) => s.furnitureData);
  const unitMode = useAppStore((s) => s.unitMode);
  const metricPdf = useAppStore((s) => s.metricPdf);
  const imperialPdf = useAppStore((s) => s.imperialPdf);
  const combinedPdf = useAppStore((s) => s.combinedPdf);
  const catalogPdf = useAppStore((s) => s.catalogPdf);
  const catalogItems = useAppStore((s) => s.catalogItems);
  const updateField = useAppStore((s) => s.updateField);
  const setUnitMode = useAppStore((s) => s.setUnitMode);
  const resetAll = useAppStore((s) => s.resetAll);

  // Hooks
  const { lang, toggleLang } = useLanguage();
  const { handleFile, handleDrag, handleDrop, ultraCompressImage, removeImage } = useImageUpload();
  const { handleAnalyze } = useAnalysis();
  const { downloadPdf, previewPdf, handleGeneratePDFs, handleGenerateCombined, handleGenerateCatalog } = usePdfGeneration();
  const { handleAddToCatalog, handleClearCatalog, catalogCount } = useCatalog();
  const { renderDimensionInput } = useDimensions();

  // STATE: Upload
  if (appState === 'upload') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-stone-100 flex flex-col">
        <AppHeader
          lang={lang}
          onToggleLang={toggleLang}
          showCatalogBadge={true}
          catalogCount={catalogItems.length}
          actions={
            <Badge variant="secondary" className="bg-amber-50 text-amber-800 border-amber-200">
              <Layers className="w-3 h-3 mr-1" />
              {t(lang, 'header.aiPowered')}
            </Badge>
          }
        />
        <main className="flex-1 flex items-center justify-center px-4 sm:px-6 py-12">
          <div className="max-w-2xl w-full">
            <div className="text-center mb-8">
              <h2 className="text-3xl sm:text-4xl font-bold text-stone-900 mb-3">
                {t(lang, 'upload.generateProfessional')}
                <br />
                <span className="text-amber-800">{t(lang, 'upload.furnitureSpecs')}</span>
              </h2>
              <p className="text-stone-500 text-base max-w-md mx-auto">
                {t(lang, 'upload.description')}
              </p>
            </div>
            <UploadZone
              imagePreview={imagePreview}
              imageFile={imageFile}
              dragActive={dragActive}
              onDrag={handleDrag}
              onDrop={handleDrop}
              onFileSelect={handleFile}
              onRemoveImage={removeImage}
              onAnalyze={handleAnalyze}
              lang={lang}
            />
            <FeatureCards lang={lang} />
          </div>
        </main>
      </div>
    );
  }

  // STATE: Analyzing
  if (appState === 'analyzing') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-stone-100 flex flex-col">
        <AppHeader lang={lang} onToggleLang={toggleLang} />
        <main className="flex-1 flex items-center justify-center px-4 sm:px-6">
          <div className="max-w-lg w-full">
            <AnalyzingView imagePreview={imagePreview} messages={analysisMessages} lang={lang} />
          </div>
        </main>
      </div>
    );
  }

  // STATE: Editing
  if (appState === 'editing') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-stone-100 flex flex-col">
        <AppHeader
          lang={lang}
          onToggleLang={toggleLang}
          title={t(lang, 'editing.title')}
          subtitle={t(lang, 'editing.subtitle')}
          showCatalogBadge={true}
          catalogCount={catalogItems.length}
          actions={
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleAddToCatalog(ultraCompressImage)}
                className="text-green-700 border-green-300 hover:bg-green-50"
              >
                <Plus className="w-4 h-4 mr-1" />
                {t(lang, 'catalog.addToCatalog')}
              </Button>
              <Button variant="outline" size="sm" onClick={resetAll} className="text-stone-600">
                <RotateCcw className="w-4 h-4 mr-1" />
                {t(lang, 'editing.startOver')}
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="border-amber-300 text-amber-800 hover:bg-amber-50"
                onClick={() => handleGenerateCombined(ultraCompressImage)}
              >
                <FileText className="w-4 h-4 mr-1" />
                {t(lang, 'complete.combinedVersion')}
              </Button>
              {catalogItems.length > 0 && (
                <Button
                  size="sm"
                  className="bg-green-800 hover:bg-green-900 text-white"
                  onClick={() => handleGenerateCatalog(ultraCompressImage)}
                >
                  <Layers className="w-4 h-4 mr-1" />
                  {t(lang, 'catalog.generateCatalog')}
                </Button>
              )}
              <Button
                size="sm"
                className="bg-amber-800 hover:bg-amber-900 text-white"
                onClick={() => handleGeneratePDFs(ultraCompressImage)}
              >
                <FileText className="w-4 h-4 mr-1" />
                {t(lang, 'editing.generatePdfs')}
              </Button>
            </>
          }
        />
        <EditingView
          furnitureData={furnitureData}
          imagePreview={imagePreview}
          lang={lang}
          unitMode={unitMode}
          catalogCount={catalogCount}
          onUpdateField={updateField}
          onSetUnitMode={setUnitMode}
          onAddToCatalog={() => handleAddToCatalog(ultraCompressImage)}
          onStartOver={resetAll}
          onGeneratePDFs={() => handleGeneratePDFs(ultraCompressImage)}
          onGenerateCombined={() => handleGenerateCombined(ultraCompressImage)}
          onGenerateCatalog={() => handleGenerateCatalog(ultraCompressImage)}
          renderDimensionInput={renderDimensionInput}
        />
      </div>
    );
  }

  // STATE: Generating
  if (appState === 'generating') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-stone-100 flex flex-col">
        <AppHeader
          lang={lang}
          onToggleLang={toggleLang}
          title={t(lang, 'generating.title')}
        />
        <main className="flex-1 flex items-center justify-center px-4 sm:px-6">
          <GeneratingView lang={lang} />
        </main>
      </div>
    );
  }

  // STATE: Complete
  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-stone-100 flex flex-col">
      <AppHeader
        lang={lang}
        onToggleLang={toggleLang}
        title={t(lang, 'complete.pdfsGenerated')}
        subtitle={t(lang, 'complete.sheetsReady')}
        variant="success"
        actions={
          <>
            <Button variant="outline" size="sm" onClick={resetAll} className="text-stone-600">
              <RotateCcw className="w-4 h-4 mr-1" />
              {t(lang, 'editing.startOver')}
            </Button>
          </>
        }
      />
      <CompleteView
        metricPdf={metricPdf}
        imperialPdf={imperialPdf}
        combinedPdf={combinedPdf}
        catalogPdf={catalogPdf}
        furnitureData={furnitureData}
        catalogCount={catalogItems.length}
        onDownload={downloadPdf}
        onPreview={previewPdf}
        onEditSpecs={() => useAppStore.getState().setState('editing')}
        onNewAnalysis={resetAll}
        lang={lang}
      />
    </div>
  );
}
