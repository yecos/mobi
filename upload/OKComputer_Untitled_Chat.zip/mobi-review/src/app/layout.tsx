import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Furniture Spec Generator — TEMPLO Interior Design",
  description: "Upload a furniture photo and generate professional specification sheets in metric and imperial units using AI vision. By TEMPLO Interior Design.",
  keywords: ["furniture", "specifications", "AI", "vision", "interior design", "PDF", "metric", "imperial", "TEMPLO"],
  authors: [{ name: "TEMPLO Interior Design" }],
  openGraph: {
    title: "Furniture Spec Generator — TEMPLO Interior Design",
    description: "AI-powered furniture specification sheets in metric and imperial units",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Furniture Spec Generator — TEMPLO Interior Design",
    description: "AI-powered furniture specification sheets in metric and imperial units",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="light">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
