import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import os from 'os';

// Force dynamic rendering (no caching)
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

// ===================== ENVIRONMENT DETECTION =====================
function isVercel(): boolean {
  return !!(process.env.VERCEL || process.env.VERCEL_URL);
}

// ===================== Z-AI CONFIG HELPER =====================
async function ensureZAIConfig(): Promise<boolean> {
  const configPaths = [
    path.join(process.cwd(), '.z-ai-config'),
    path.join(os.homedir(), '.z-ai-config'),
    '/etc/.z-ai-config',
  ];

  for (const p of configPaths) {
    try {
      const content = fs.readFileSync(p, 'utf-8');
      const config = JSON.parse(content);
      if (config.baseUrl && config.apiKey) {
        // On Vercel, internal IPs (172.x.x.x) are NOT reachable
        if (isVercel() && config.baseUrl.includes('172.')) {
          console.warn('[generate-drawing] Z-AI config has internal IP, not reachable from Vercel');
          continue;
        }
        return true;
      }
    } catch {
      // File doesn't exist or invalid
    }
  }

  // Try to create from env vars
  const baseUrl = process.env.ZAI_BASE_URL;
  const apiKey = process.env.ZAI_API_KEY;
  if (!baseUrl || !apiKey) return false;

  // On Vercel, check if the baseUrl is reachable
  if (isVercel() && baseUrl.includes('172.')) {
    console.warn('[generate-drawing] ZAI_BASE_URL is internal IP, not reachable from Vercel');
    return false;
  }

  try {
    const configPath = path.join(process.cwd(), '.z-ai-config');
    fs.writeFileSync(configPath, JSON.stringify({
      baseUrl,
      apiKey,
      chatId: process.env.ZAI_CHAT_ID,
      token: process.env.ZAI_TOKEN,
      userId: process.env.ZAI_USER_ID,
    }, null, 2));
    console.log('[generate-drawing] Created .z-ai-config from environment variables');
    return true;
  } catch (err) {
    console.warn('[generate-drawing] Could not write .z-ai-config:', err);
    return false;
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { furnitureData } = body as {
      furnitureData: {
        productName?: string;
        category?: string;
        description?: string;
        descriptionEs?: string;
        dimensions?: {
          height?: { feet: number; inches: number };
          width?: { feet: number; inches: number };
          depth?: { feet: number; inches: number };
        };
        materials?: string[];
        shapeProfile?: {
          bodyShape?: string;
          hasBackrest?: boolean;
          hasArmrests?: boolean;
          backrestShape?: string;
          legType?: string;
          legCount?: number;
          cornerStyle?: string;
          armrestShape?: string;
          seatShape?: string;
          topViewOutline?: string;
          sideProfile?: string;
        };
      };
    };

    if (!furnitureData) {
      return NextResponse.json({ error: 'No furniture data provided' }, { status: 400 });
    }

    console.log('[generate-drawing] Generating technical drawing for:', furnitureData.productName || 'Unknown');

    const category = furnitureData.category || 'furniture';
    const name = furnitureData.productName || category;
    const dims = furnitureData.dimensions || {};
    const heightM = dims.height ? (dims.height.feet * 0.3048 + dims.height.inches * 0.0254).toFixed(2) : '0.80';
    const widthM = dims.width ? (dims.width.feet * 0.3048 + dims.width.inches * 0.0254).toFixed(2) : '1.80';
    const depthM = dims.depth ? (dims.depth.feet * 0.3048 + dims.depth.inches * 0.0254).toFixed(2) : '0.80';

    const sp = furnitureData.shapeProfile || {};

    // Build the prompt - extremely detailed for professional technical drawings
    const prompt = buildTechnicalDrawingPrompt(name, category, widthM, depthM, heightM, sp);

    console.log('[generate-drawing] Prompt length:', prompt.length);

    // Try Z-AI SDK first (works locally with config file)
    const configReady = await ensureZAIConfig();
    if (configReady) {
      try {
        const zai = await ZAI.create();
        const response = await zai.images.generations.create({
          prompt,
          size: '1152x864',
        });

        const imageBase64 = response.data[0]?.base64;
        if (imageBase64) {
          console.log(`[generate-drawing] ✅ Image generated via Z-AI SDK (${imageBase64.length} chars base64)`);
          return NextResponse.json({ success: true, imageBase64 });
        }
      } catch (zaiErr) {
        console.warn('[generate-drawing] Z-AI SDK failed:', zaiErr instanceof Error ? zaiErr.message : String(zaiErr));
      }
    }

    // Fallback: Return null drawing (PDF will use parametric blueprint engine)
    // The parametric engine generates clean technical drawings without AI
    console.log('[generate-drawing] Using parametric blueprint engine as fallback');
    return NextResponse.json({
      success: true,
      imageBase64: null,
      fallback: 'parametric',
    });
  } catch (error) {
    console.error('[generate-drawing] Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to generate technical drawing: ' + (error instanceof Error ? error.message : String(error)),
      },
      { status: 500 }
    );
  }
}

function buildTechnicalDrawingPrompt(
  name: string,
  category: string,
  widthM: string,
  depthM: string,
  heightM: string,
  sp: {
    bodyShape?: string;
    hasBackrest?: boolean;
    hasArmrests?: boolean;
    backrestShape?: string;
    legType?: string;
    legCount?: number;
    cornerStyle?: string;
    armrestShape?: string;
    seatShape?: string;
    topViewOutline?: string;
    sideProfile?: string;
  }
): string {
  const features = buildFeatureDescription(sp, category);
  const frontDesc = buildFrontViewDescription(sp, category);
  const planDesc = buildPlanViewDescription(sp, category);
  const sideDesc = buildSideViewDescription(sp, category);

  return `Professional architectural technical drawing of a ${name} (${category}).

THREE ORTHOGRAPHIC VIEWS arranged on white background:

TOP HALF — FRONT ELEVATION (viewed from front, showing width ${widthM}m × height ${heightM}m):
${frontDesc}

BOTTOM LEFT — PLAN VIEW (viewed from above/top-down, showing width ${widthM}m × depth ${depthM}m):
${planDesc}

BOTTOM RIGHT — SIDE ELEVATION (viewed from right side, showing depth ${depthM}m × height ${heightM}m):
${sideDesc}

Key features: ${features}

CRITICAL STYLE REQUIREMENTS:
- Pure white background, absolutely no gray areas or shading
- ONLY thin precise black lines (0.5pt weight) — NO fills, NO shadows, NO gradients, NO color, NO hatching
- Professional architectural/engineering drafting style (like AutoCAD technical drawings)
- Accurate proportions matching the real dimensions
- Show cushion seams, seat divisions, structural details as thin dashed lines
- Clear spacing between the three views
- Each view must be drawn in correct proportion to the others
- No text, no labels, no dimension arrows, no title block — pure line drawing only
- Lines must be clean and precise, not sketchy or hand-drawn
- Show visible edges as solid lines, hidden edges as short dashed lines
- Include ground line beneath each elevation view as a thin solid line`;
}

function buildFeatureDescription(
  sp: {
    bodyShape?: string;
    hasBackrest?: boolean;
    hasArmrests?: boolean;
    backrestShape?: string;
    legType?: string;
    legCount?: number;
    cornerStyle?: string;
    armrestShape?: string;
    seatShape?: string;
  },
  category: string
): string {
  const parts: string[] = [];

  if (sp.hasBackrest) parts.push('has backrest');
  if (sp.hasArmrests) parts.push('has armrests');
  if (sp.backrestShape && sp.backrestShape !== 'none') {
    parts.push(`${sp.backrestShape} backrest`);
  }
  if (sp.armrestShape && sp.armrestShape !== 'none') {
    parts.push(`${sp.armrestShape} armrests`);
  }
  if (sp.legType && sp.legType !== 'none') {
    parts.push(`${sp.legCount || 4} ${sp.legType} legs`);
  }
  if (sp.cornerStyle && sp.cornerStyle !== 'sharp') {
    parts.push(`${sp.cornerStyle} corners`);
  }
  if (sp.bodyShape && sp.bodyShape !== 'rectangular') {
    parts.push(`${sp.bodyShape} body`);
  }
  if (sp.seatShape && sp.seatShape !== 'flat') {
    parts.push(`${sp.seatShape} seat`);
  }

  if (parts.length === 0) {
    return `${category} with standard construction`;
  }
  return parts.join(', ');
}

function buildFrontViewDescription(
  sp: {
    hasBackrest?: boolean;
    backrestShape?: string;
    hasArmrests?: boolean;
    armrestShape?: string;
    legType?: string;
    legCount?: number;
    cornerStyle?: string;
    seatShape?: string;
    bodyShape?: string;
  },
  category: string
): string {
  const parts: string[] = [];

  // Base shape description
  const isCurved = sp.cornerStyle?.includes('rounded') || sp.cornerStyle?.includes('curved') ||
    sp.bodyShape?.includes('curved') || sp.bodyShape?.includes('rounded') || sp.bodyShape?.includes('organic');

  if (isCurved) {
    parts.push('The outline has smooth curved edges and rounded corners (NOT sharp rectangular corners)');
  }

  // Backrest
  if (sp.hasBackrest) {
    if (sp.backrestShape === 'curved' || sp.backrestShape === 'solid-curved') {
      parts.push('The backrest has a smooth curved/arched top edge that curves upward in the center');
    } else if (sp.backrestShape === 'winged') {
      parts.push('The backrest has winged sides that curve upward on the left and right edges');
    } else if (sp.backrestShape === 'channel-tufted') {
      parts.push('The backrest has vertical channel tufting lines running from top to seat');
    } else {
      parts.push('The backrest is flat across the top');
    }

    // Cushion divisions in backrest
    if (category === 'sofa') {
      parts.push('The backrest is divided into 3 equal cushion sections with vertical dashed lines');
    } else if (category === 'chair') {
      parts.push('The backrest is a single cushion section');
    }
  }

  // Seat
  if (category === 'sofa') {
    parts.push('The seat is divided into 3 equal cushion sections with vertical dashed lines');
  } else if (category === 'chair') {
    parts.push('The seat is a single cushion');
  }

  if (sp.seatShape === 'cushioned') {
    parts.push('The seat cushion has a slight bulge/curve on top surface');
  }

  // Armrests
  if (sp.hasArmrests) {
    if (sp.armrestShape === 'scroll') {
      parts.push('Scroll armrests on both sides — each armrest has a distinctive rolled/scroll curve at the top');
    } else if (sp.armrestShape === 'curved') {
      parts.push('Curved armrests on both sides that sweep upward from the seat');
    } else if (sp.armrestShape === 'integrated') {
      parts.push('The armrests are integrated flush with the body, barely protruding');
    } else {
      parts.push('Straight geometric armrests on both sides at the same height as the backrest');
    }
  }

  // Legs
  if (sp.legType && sp.legType !== 'none') {
    const count = sp.legCount || 4;
    if (sp.legType === 'tapered') {
      parts.push(`${count} tapered legs that narrow toward the bottom, visible at the base`);
    } else if (sp.legType === 'splayed') {
      parts.push(`${count} splayed legs that angle outward from the base`);
    } else if (sp.legType === 'metal-frame') {
      parts.push('Thin metal frame legs forming an angular base structure with a crossbar');
    } else if (sp.legType === 'block') {
      parts.push(`Short block/square legs under the base`);
    } else if (sp.legType === 'pedestal') {
      parts.push('A single pedestal base centered under the seat');
    } else {
      parts.push(`${count} straight cylindrical legs visible at the bottom`);
    }
  }

  return parts.join('. ') || 'Standard front elevation view';
}

function buildPlanViewDescription(
  sp: {
    hasBackrest?: boolean;
    hasArmrests?: boolean;
    cornerStyle?: string;
    bodyShape?: string;
    topViewOutline?: string;
    armrestShape?: string;
  },
  category: string
): string {
  const parts: string[] = [];

  // Shape from above
  const isOval = sp.bodyShape?.includes('oval') || sp.bodyShape?.includes('circular');
  const isCurved = sp.cornerStyle?.includes('rounded') || sp.cornerStyle?.includes('curved') ||
    sp.bodyShape?.includes('curved') || sp.bodyShape?.includes('rounded') || sp.bodyShape?.includes('organic');

  if (isOval) {
    parts.push('Oval/elliptical outline shape viewed from above');
  } else if (isCurved) {
    parts.push('Rectangular outline with fully rounded corners viewed from above');
  } else {
    parts.push('Clean rectangular outline viewed from above');
  }

  // Backrest strip
  if (sp.hasBackrest) {
    parts.push('A narrow backrest strip is visible along the bottom edge (far side from viewer)');
  }

  // Armrests from above
  if (sp.hasArmrests) {
    if (sp.armrestShape === 'scroll') {
      parts.push('Scroll armrests visible as thick curved strips on the left and right sides');
    } else {
      parts.push('Armrests visible as narrow strips on the left and right sides');
    }
  }

  // Cushion divisions from above
  if (category === 'sofa') {
    parts.push('Three seat cushion sections visible with dashed dividing lines');
  } else if (category === 'chair') {
    parts.push('Single seat cushion visible');
  }

  return parts.join('. ') || 'Standard plan view from above';
}

function buildSideViewDescription(
  sp: {
    hasBackrest?: boolean;
    backrestShape?: string;
    legType?: string;
    legCount?: number;
    cornerStyle?: string;
    seatShape?: string;
    bodyShape?: string;
    sideProfile?: string;
    hasArmrests?: boolean;
  },
  category: string
): string {
  const parts: string[] = [];

  parts.push('Narrower profile view from the side');

  const isCurved = sp.cornerStyle?.includes('rounded') || sp.cornerStyle?.includes('curved') ||
    sp.bodyShape?.includes('curved') || sp.bodyShape?.includes('rounded');

  // Overall profile
  if (sp.hasBackrest) {
    if (isCurved || sp.backrestShape === 'curved' || sp.backrestShape === 'solid-curved') {
      parts.push('C-shaped curved profile — the backrest curves smoothly into the seat with rounded transitions');
    } else {
      parts.push('L-shaped profile — the backrest is on the right side extending upward at 90 degrees from the seat');
    }

    if (sp.backrestShape === 'winged') {
      parts.push('The backrest top edge has a subtle forward curve at the top');
    }
  }

  // Armrest from side
  if (sp.hasArmrests) {
    parts.push('The armrest is visible as a small protrusion on the near side of the seat');
  }

  // Seat from side
  if (sp.seatShape === 'cushioned') {
    parts.push('The seat cushion has a slight curve/bulge on top');
  }

  // Legs from side
  if (sp.legType && sp.legType !== 'none') {
    if (sp.legType === 'tapered') {
      parts.push('Two tapered legs visible, narrowing toward the floor');
    } else if (sp.legType === 'splayed') {
      parts.push('Two splayed legs visible, angling outward');
    } else if (sp.legType === 'metal-frame') {
      parts.push('Thin metal legs visible with angular geometry');
    } else {
      parts.push('Two legs visible at the bottom');
    }
  }

  return parts.join('. ') || 'Standard side elevation view';
}
