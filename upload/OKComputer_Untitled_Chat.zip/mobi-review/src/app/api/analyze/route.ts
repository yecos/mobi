import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import os from 'os';

// Force dynamic rendering (no caching)
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

// ===================== TIMEOUT HELPER =====================
const PROVIDER_TIMEOUT = 25_000; // 25s per external provider
const QUICK_TIMEOUT = 15_000; // 15s for quick-fail providers

function fetchWithTimeout(url: string, options: RequestInit, timeoutMs: number): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  return fetch(url, { ...options, signal: controller.signal })
    .finally(() => clearTimeout(timer));
}

// ===================== ENVIRONMENT DETECTION =====================
function isVercel(): boolean {
  return !!(process.env.VERCEL || process.env.VERCEL_URL);
}

function isLocalDev(): boolean {
  return !isVercel();
}

// ===================== PROMPT =====================
const PROMPT_TEXT = `Analyze this furniture image. Return JSON ONLY (no markdown, no code blocks):
{
  "productName": "string",
  "brand": "string or Unknown",
  "referenceNumber": "string or N/A",
  "description": "detailed English description",
  "descriptionEs": "same description in Spanish",
  "dimensions": {
    "height": { "feet": 0, "inches": 0 },
    "width": { "feet": 0, "inches": 0 },
    "depth": { "feet": 0, "inches": 0 },
    "widthExtended": { "feet": 0, "inches": 0 },
    "seatDepth": { "feet": 0, "inches": 0 },
    "depthExtended": { "feet": 0, "inches": 0 }
  },
  "materials": ["string"],
  "quantity": 1,
  "colorFinishes": [{ "name": "string", "color": "#hex" }],
  "loungeConfigurations": [{ "name": "string", "units": 0 }],
  "category": "sofa|chair|table|cabinet|bed|desk|shelving",
  "tags": ["string"],
  "shapeProfile": {
    "bodyShape": "rectangular|rounded|curved|L-shape|circular|oval|tapered|organic",
    "cornerStyle": "sharp|slightly-rounded|fully-rounded|curved",
    "hasBackrest": false,
    "backrestShape": "flat|curved|winged|channel-tufted|solid-curved|none",
    "hasArmrests": false,
    "armrestShape": "none|straight|curved|scroll|integrated",
    "legType": "none|cylindrical|tapered|splayed|pedestal|block|metal-frame",
    "legCount": 4,
    "seatShape": "flat|cushioned|curved|bucket|saddle",
    "topViewOutline": "describe top-down shape",
    "sideProfile": "describe side profile shape"
  }
}
RULES: Dimensions in feet+inches (1m=3.28084ft). height,width,depth REQUIRED. widthExtended/seatDepth/depthExtended use {feet:0,inches:0} if N/A. shapeProfile REQUIRED.`;

// ===================== PROVIDER TYPES =====================
interface ProviderResult {
  success: boolean;
  data?: unknown;
  error?: string;
  provider?: string;
}

// ===================== Z-AI CONFIG HELPER =====================
// Z-AI SDK works locally (config file in /etc/.z-ai-config)
// On Vercel, it requires ZAI_BASE_URL + ZAI_API_KEY env vars
// Note: The default Z-AI baseUrl (http://172.x.x.x:8080) is an INTERNAL IP
// that is NOT reachable from Vercel's servers. For Vercel deployment,
// you MUST configure external API keys (Gemini, Groq, or OpenRouter).

async function ensureZAIConfig(): Promise<boolean> {
  // Check if config already exists in standard locations
  const configPaths = [
    path.join(process.cwd(), '.z-ai-config'),
    path.join(os.homedir(), '.z-ai-config'),
    '/etc/.z-ai-config',
  ];

  for (const p of configPaths) {
    try {
      const content = fs.readFileSync(p, 'utf-8');
      const config = JSON.parse(content);
      if (config.baseUrl && config.apiKey) {
        // On Vercel, check if the baseUrl is reachable (internal IPs won't work)
        if (isVercel() && config.baseUrl.includes('172.')) {
          console.warn('[analyze] Z-AI config has internal IP, not reachable from Vercel');
          continue;
        }
        return true;
      }
    } catch {
      // File doesn't exist or invalid
    }
  }

  // No config file found - try to create one from env vars
  const baseUrl = process.env.ZAI_BASE_URL;
  const apiKey = process.env.ZAI_API_KEY;
  if (!baseUrl || !apiKey) return false;

  // On Vercel, check if the baseUrl is reachable
  if (isVercel() && baseUrl.includes('172.')) {
    console.warn('[analyze] ZAI_BASE_URL is internal IP, not reachable from Vercel');
    return false;
  }

  try {
    const configPath = path.join(process.cwd(), '.z-ai-config');
    fs.writeFileSync(configPath, JSON.stringify({
      baseUrl,
      apiKey,
      chatId: process.env.ZAI_CHAT_ID,
      token: process.env.ZAI_TOKEN,
      userId: process.env.ZAI_USER_ID,
    }, null, 2));
    console.log('[analyze] Created .z-ai-config from environment variables');
    return true;
  } catch (err) {
    console.warn('[analyze] Could not write .z-ai-config:', err);
    return false;
  }
}

// ===================== PROVIDER 0: Z-AI WEB DEV SDK =====================
async function tryZAI(base64: string, mimeType: string): Promise<ProviderResult> {
  console.log('[analyze] Trying Z-AI SDK (Vision)...');

  try {
    // Ensure config file exists (from env vars if needed)
    const configReady = await ensureZAIConfig();
    if (!configReady) {
      return { success: false, error: 'Z-AI config not available (no config file and no ZAI_BASE_URL/ZAI_API_KEY env vars)' };
    }

    const zai = await ZAI.create();
    const imageUrl = `data:${mimeType};base64,${base64}`;

    const response = await zai.chat.completions.createVision({
      model: 'glm-4v-plus',
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: PROMPT_TEXT },
          { type: 'image_url', image_url: { url: imageUrl } },
        ],
      }],
      stream: false,
    });

    const content = response.choices?.[0]?.message?.content || '';
    if (!content || content.length < 10) {
      return { success: false, error: 'Z-AI returned empty response' };
    }

    console.log(`[analyze] Z-AI response: ${content.length} chars`);
    return { success: true, data: content, provider: 'Z-AI (GLM-4V Plus)' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.warn('[analyze] Z-AI exception:', msg);
    return { success: false, error: `Z-AI failed: ${msg}` };
  }
}

// ===================== PROVIDER 1: GEMINI (FREE, WITH RETRY) =====================
async function tryGemini(base64: string, mimeType: string, retryCount = 0): Promise<ProviderResult> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return { success: false, error: 'GEMINI_API_KEY not set' };

  console.log(`[analyze] Trying Gemini 2.0 Flash${retryCount > 0 ? ` (retry ${retryCount})` : ''}...`);

  try {
    const response = await fetchWithTimeout(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [
              { text: PROMPT_TEXT },
              { inline_data: { mime_type: mimeType, data: base64 } },
            ],
          }],
          generationConfig: { temperature: 0.2, maxOutputTokens: 8000 },
        }),
      },
      PROVIDER_TIMEOUT
    );

    if (!response.ok) {
      const errText = await response.text();

      // Retry on 429 (rate limit) with exponential backoff
      if (response.status === 429 && retryCount < 2) {
        const delay = Math.pow(2, retryCount) * 3000; // 3s, 6s
        console.log(`[analyze] Gemini rate limited, retrying in ${delay}ms...`);
        await new Promise((r) => setTimeout(r, delay));
        return tryGemini(base64, mimeType, retryCount + 1);
      }

      console.warn(`[analyze] Gemini error (${response.status}): ${errText.substring(0, 150)}`);
      return { success: false, error: `Gemini ${response.status}` };
    }

    const data = await response.json();
    const content = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    if (!content || content.length < 10) {
      return { success: false, error: 'Gemini returned empty response' };
    }
    console.log(`[analyze] Gemini response: ${content.length} chars`);
    return { success: true, data: content, provider: 'Gemini 2.0 Flash' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('abort')) return { success: false, error: 'Gemini timed out' };
    console.warn('[analyze] Gemini exception:', msg);
    return { success: false, error: `Gemini failed: ${msg}` };
  }
}

// ===================== PROVIDER 2: GROQ (FAST, FREE) =====================
async function tryGroq(base64: string, mimeType: string): Promise<ProviderResult> {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) return { success: false, error: 'GROQ_API_KEY not set' };

  // Try multiple model names (some may be deprecated)
  const models = [
    'llama-3.2-90b-vision-preview',
    'llama-3.2-11b-vision-preview',
    'meta-llama/llama-4-scout-17b-16e-instruct',
  ];

  for (const model of models) {
    console.log(`[analyze] Trying Groq (${model})...`);

    try {
      const imageUrl = `data:${mimeType};base64,${base64}`;

      const response = await fetchWithTimeout('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages: [{
            role: 'user',
            content: [
              { type: 'text', text: PROMPT_TEXT },
              { type: 'image_url', image_url: { url: imageUrl } },
            ],
          }],
          max_tokens: 8000,
          temperature: 0.2,
        }),
      }, QUICK_TIMEOUT);

      if (!response.ok) {
        const errText = await response.text();
        console.warn(`[analyze] Groq ${model} error (${response.status}): ${errText.substring(0, 150)}`);
        continue; // Try next model
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || '';
      if (!content || content.length < 10) {
        console.warn(`[analyze] Groq ${model} returned empty`);
        continue;
      }
      console.log(`[analyze] Groq ${model} response: ${content.length} chars`);
      return { success: true, data: content, provider: `Groq (${model})` };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('abort')) {
        console.warn(`[analyze] Groq ${model} timed out`);
        continue;
      }
      console.warn(`[analyze] Groq ${model} exception:`, msg);
      continue;
    }
  }

  return { success: false, error: 'All Groq models failed' };
}

// ===================== PROVIDER 3: OPENROUTER (FREE MODELS) =====================
async function tryOpenRouter(base64: string, mimeType: string): Promise<ProviderResult> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) return { success: false, error: 'OPENROUTER_API_KEY not set' };

  const models = [
    'google/gemma-3-27b-it:free',
    'google/gemma-4-26b-a4b-it:free',
    'nvidia/nemotron-nano-12b-v2-vl:free',
  ];

  for (const model of models) {
    console.log(`[analyze] Trying OpenRouter (${model})...`);

    try {
      const imageUrl = `data:${mimeType};base64,${base64}`;

      const response = await fetchWithTimeout('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
          'HTTP-Referer': 'https://mobi-vert-tau.vercel.app',
          'X-Title': 'TEMPLO Furniture Spec Generator',
        },
        body: JSON.stringify({
          model,
          messages: [{
            role: 'user',
            content: [
              { type: 'text', text: PROMPT_TEXT },
              { type: 'image_url', image_url: { url: imageUrl } },
            ],
          }],
          max_tokens: 8000,
          temperature: 0.2,
        }),
      }, QUICK_TIMEOUT);

      if (!response.ok) {
        const errText = await response.text();
        console.warn(`[analyze] OpenRouter ${model} error (${response.status}): ${errText.substring(0, 100)}`);
        continue;
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || '';

      if (!content || content.length < 10) {
        console.warn(`[analyze] OpenRouter ${model} returned empty`);
        continue;
      }

      console.log(`[analyze] OpenRouter ${model} response: ${content.length} chars`);
      return { success: true, data: content, provider: `OpenRouter (${model})` };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('abort')) {
        console.warn(`[analyze] OpenRouter ${model} timed out`);
        continue;
      }
      console.warn(`[analyze] OpenRouter ${model} exception:`, msg);
      continue;
    }
  }

  return { success: false, error: 'All OpenRouter models failed' };
}

// ===================== PROVIDER 4: OPENAI (PAID, RELIABLE) =====================
async function tryOpenAI(base64: string, mimeType: string): Promise<ProviderResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return { success: false, error: 'OPENAI_API_KEY not set' };

  console.log('[analyze] Trying OpenAI GPT-4o Vision...');

  try {
    const imageUrl = `data:${mimeType};base64,${base64}`;

    const response = await fetchWithTimeout('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [{
          role: 'user',
          content: [
            { type: 'text', text: PROMPT_TEXT },
            { type: 'image_url', image_url: { url: imageUrl, detail: 'high' } },
          ],
        }],
        max_tokens: 8000,
        temperature: 0.2,
      }),
    }, PROVIDER_TIMEOUT);

    if (!response.ok) {
      const errText = await response.text();
      console.warn(`[analyze] OpenAI error (${response.status}): ${errText.substring(0, 150)}`);
      return { success: false, error: `OpenAI ${response.status}` };
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || '';
    if (!content || content.length < 10) {
      return { success: false, error: 'OpenAI returned empty response' };
    }
    console.log(`[analyze] OpenAI response: ${content.length} chars`);
    return { success: true, data: content, provider: 'OpenAI GPT-4o' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('abort')) return { success: false, error: 'OpenAI timed out' };
    console.warn('[analyze] OpenAI exception:', msg);
    return { success: false, error: `OpenAI failed: ${msg}` };
  }
}

// ===================== PARSE RESPONSE =====================
function parseAIResponse(content: string): { parsed: unknown } | { error: string; raw: string } {
  let jsonStr = content.trim();
  if (jsonStr.includes('```json')) {
    jsonStr = jsonStr.split('```json')[1].split('```')[0].trim();
  } else if (jsonStr.includes('```')) {
    jsonStr = jsonStr.split('```')[1].split('```')[0].trim();
  }
  jsonStr = jsonStr.trim();

  try {
    const parsed = JSON.parse(jsonStr) as Record<string, unknown>;
    return { parsed };
  } catch {
    console.error('[analyze] JSON parse failed. Raw:', content.substring(0, 300));
    return { error: 'Failed to parse furniture data from AI response', raw: content };
  }
}

// ===================== MAIN HANDLER =====================
export async function POST(req: NextRequest) {
  try {
    console.log('[analyze] Starting image analysis...');

    const formData = await req.formData();
    const imageFile = formData.get('image') as File;

    if (!imageFile) {
      return NextResponse.json({ error: 'No image provided' }, { status: 400 });
    }

    console.log(`[analyze] Image: ${imageFile.name}, type: ${imageFile.type}, size: ${(imageFile.size / 1024).toFixed(1)}KB`);

    // Convert to base64
    const bytes = await imageFile.arrayBuffer();
    const base64 = Buffer.from(bytes).toString('base64');
    const mimeType = imageFile.type;

    // Strategy: Try ALL providers in parallel for fastest response
    const providers: Array<() => Promise<ProviderResult>> = [];

    // On local dev: Z-AI SDK works (internal config file)
    // On Vercel: External API keys are required (Gemini, Groq, OpenRouter, OpenAI)
    const zaiConfigReady = await ensureZAIConfig();
    if (zaiConfigReady) {
      providers.push(() => tryZAI(base64, mimeType));
    } else if (isVercel()) {
      console.log('[analyze] Z-AI SDK not available on Vercel (requires external API keys)');
    }

    // External providers (work on both local and Vercel when API keys are set)
    if (process.env.GEMINI_API_KEY) providers.push(() => tryGemini(base64, mimeType));
    if (process.env.GROQ_API_KEY) providers.push(() => tryGroq(base64, mimeType));
    if (process.env.OPENROUTER_API_KEY) providers.push(() => tryOpenRouter(base64, mimeType));
    if (process.env.OPENAI_API_KEY) providers.push(() => tryOpenAI(base64, mimeType));

    if (providers.length === 0) {
      const isVercelDeploy = isVercel();
      const helpMsg = isVercelDeploy
        ? 'No AI providers configured. Go to your Vercel project Settings > Environment Variables and add at least one: GEMINI_API_KEY (free at aistudio.google.com/apikey), GROQ_API_KEY (free at console.groq.com), or OPENROUTER_API_KEY (free at openrouter.ai). Then redeploy.'
        : 'No AI providers available. Please configure at least one API key in .env file.';
      console.error('[analyze] No providers available. Vercel:', isVercelDeploy);
      return NextResponse.json(
        { success: false, error: helpMsg, needsApiKeys: true },
        { status: 500 }
      );
    }

    // If only one provider, try it directly
    if (providers.length === 1) {
      const result = providers[0]();
      const resolved = await result;
      if (resolved.success && resolved.data) {
        const content = resolved.data as string;
        const parsed = parseAIResponse(content);
        if ('parsed' in parsed) {
          console.log(`[analyze] ✅ Success with ${resolved.provider}`);
          return NextResponse.json({ success: true, data: parsed.parsed, provider: resolved.provider });
        }
      }
      return NextResponse.json(
        { success: false, error: 'AI provider failed', details: resolved.error },
        { status: 500 }
      );
    }

    // Race all providers — first successful result wins
    const errors: string[] = [];
    let resolved = false;

    const result = await new Promise<ProviderResult>((resolve) => {
      let pending = providers.length;

      for (const providerFn of providers) {
        providerFn().then((res) => {
          pending--;
          if (res.success && !resolved) {
            resolved = true;
            resolve(res);
          } else if (!res.success) {
            errors.push(res.error || 'Unknown error');
            if (pending === 0 && !resolved) {
              resolve({ success: false, error: errors.join('; ') });
            }
          }
        }).catch((err) => {
          pending--;
          errors.push(err instanceof Error ? err.message : String(err));
          if (pending === 0 && !resolved) {
            resolve({ success: false, error: errors.join('; ') });
          }
        });
      }
    });

    if (result.success && result.data) {
      const content = result.data as string;
      const parsed = parseAIResponse(content);

      if ('parsed' in parsed) {
        console.log(`[analyze] ✅ Success with ${result.provider}`);
        return NextResponse.json({
          success: true,
          data: parsed.parsed,
          provider: result.provider,
        });
      } else {
        console.warn(`[analyze] ${result.provider} returned unparseable response`);
        return NextResponse.json(
          { success: false, error: parsed.error, raw: parsed.raw?.substring(0, 500) },
          { status: 500 }
        );
      }
    }

    // All providers failed
    console.error('[analyze] All AI providers failed:', result.error);
    return NextResponse.json(
      {
        success: false,
        error: 'All AI providers failed. Please check your API key configuration.',
        details: result.error,
      },
      { status: 500 }
    );
  } catch (error) {
    console.error('[analyze] Unexpected error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to analyze image: ' + (error instanceof Error ? error.message : String(error)) },
      { status: 500 }
    );
  }
}
