'use client';

import React from 'react';
import { CheckCircle2, FileText, Download, Ruler, Layers, AlertCircle } from 'lucide-react';
import { t } from '@/lib/i18n';
import type { Lang } from '@/lib/i18n';
import type { FurnitureData } from '@/lib/types';
import { feetInchesToMeters } from '@/lib/convert';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface CompleteViewProps {
  metricPdf: string | null;
  imperialPdf: string | null;
  combinedPdf: string | null;
  catalogPdf: string | null;
  furnitureData: FurnitureData;
  catalogCount: number;
  onDownload: (base64: string, filename: string) => void;
  onPreview: (base64: string) => void;
  onEditSpecs: () => void;
  onNewAnalysis: () => void;
  lang: Lang;
}

export function CompleteView({
  metricPdf,
  imperialPdf,
  combinedPdf,
  catalogPdf,
  furnitureData,
  catalogCount,
  onDownload,
  onPreview,
  onEditSpecs,
  onNewAnalysis,
  lang,
}: CompleteViewProps) {
  return (
    <main className="flex-1 max-w-6xl mx-auto px-4 sm:px-6 py-8">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-stone-900 mb-2">
          {t(lang, 'complete.downloadSheets')}
        </h2>
        <p className="text-stone-500">
          {t(lang, 'complete.bothVersions')}{' '}
          <span className="font-semibold text-amber-800">{furnitureData.productName}</span>
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {/* Metric PDF Card */}
        <Card className="border-amber-200 bg-gradient-to-br from-amber-50/80 to-white overflow-hidden">
          <div
            className="h-64 bg-stone-100 flex items-center justify-center p-4 cursor-pointer hover:bg-stone-50 transition-colors"
            onClick={() => metricPdf && onPreview(metricPdf)}
          >
            {metricPdf ? (
              <div className="text-center">
                <FileText className="w-16 h-16 text-amber-700/40 mx-auto mb-3" />
                <p className="text-sm text-stone-500">{t(lang, 'complete.clickPreviewMetric')}</p>
                <div className="mt-2 text-xs text-amber-700 font-medium bg-amber-100 px-3 py-1 rounded-full inline-block">
                  {t(lang, 'complete.metricLabel')}
                </div>
              </div>
            ) : (
              <AlertCircle className="w-12 h-12 text-stone-300" />
            )}
          </div>
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                <Ruler className="w-5 h-5 text-amber-800" />
              </div>
              <div>
                <h3 className="font-bold text-stone-900">{t(lang, 'complete.metricVersion')}</h3>
                <p className="text-xs text-stone-500">{t(lang, 'complete.dimsInMeters')}</p>
              </div>
            </div>
            <Button
              className="w-full bg-amber-800 hover:bg-amber-900 text-white"
              onClick={() =>
                metricPdf && onDownload(metricPdf, `${furnitureData.productName || 'furniture'}_metric.pdf`)
              }
              disabled={!metricPdf}
            >
              <Download className="w-4 h-4 mr-2" />
              {t(lang, 'complete.downloadMetricPdf')}
            </Button>
          </CardContent>
        </Card>

        {/* Imperial PDF Card */}
        <Card className="border-blue-200 bg-gradient-to-br from-blue-50/80 to-white overflow-hidden">
          <div
            className="h-64 bg-stone-100 flex items-center justify-center p-4 cursor-pointer hover:bg-stone-50 transition-colors"
            onClick={() => imperialPdf && onPreview(imperialPdf)}
          >
            {imperialPdf ? (
              <div className="text-center">
                <FileText className="w-16 h-16 text-blue-700/40 mx-auto mb-3" />
                <p className="text-sm text-stone-500">{t(lang, 'complete.clickPreviewImperial')}</p>
                <div className="mt-2 text-xs text-blue-700 font-medium bg-blue-100 px-3 py-1 rounded-full inline-block">
                  {t(lang, 'complete.imperialLabel')}
                </div>
              </div>
            ) : (
              <AlertCircle className="w-12 h-12 text-stone-300" />
            )}
          </div>
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <Ruler className="w-5 h-5 text-blue-800" />
              </div>
              <div>
                <h3 className="font-bold text-stone-900">{t(lang, 'complete.imperialVersion')}</h3>
                <p className="text-xs text-stone-500">{t(lang, 'complete.dimsInFeetInches')}</p>
              </div>
            </div>
            <Button
              className="w-full bg-blue-800 hover:bg-blue-900 text-white"
              onClick={() =>
                imperialPdf && onDownload(imperialPdf, `${furnitureData.productName || 'furniture'}_imperial.pdf`)
              }
              disabled={!imperialPdf}
            >
              <Download className="w-4 h-4 mr-2" />
              {t(lang, 'complete.downloadImperialPdf')}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Catalog & Combined PDF Cards */}
      {(catalogPdf || combinedPdf) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto mt-6">
          {catalogPdf && (
            <Card className="border-green-200 bg-gradient-to-br from-green-50/80 to-white overflow-hidden">
              <div
                className="h-48 bg-stone-100 flex items-center justify-center p-4 cursor-pointer hover:bg-stone-50 transition-colors"
                onClick={() => onPreview(catalogPdf)}
              >
                <div className="text-center">
                  <Layers className="w-12 h-12 text-green-700/40 mx-auto mb-2" />
                  <p className="text-sm text-stone-500">{t(lang, 'complete.clickPreviewMetric')}</p>
                  <div className="mt-2 text-xs text-green-700 font-medium bg-green-100 px-3 py-1 rounded-full inline-block">
                    {catalogCount + 1} {lang === 'en' ? 'pieces' : 'piezas'}
                  </div>
                </div>
              </div>
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                    <Layers className="w-5 h-5 text-green-800" />
                  </div>
                  <div>
                    <h3 className="font-bold text-stone-900">{t(lang, 'complete.catalogVersion')}</h3>
                    <p className="text-xs text-stone-500">
                      {lang === 'en' ? 'Multi-piece catalog with all items' : 'Catálogo multipieza con todos los artículos'}
                    </p>
                  </div>
                </div>
                <Button
                  className="w-full bg-green-800 hover:bg-green-900 text-white"
                  onClick={() => catalogPdf && onDownload(catalogPdf, 'furniture_catalog.pdf')}
                  disabled={!catalogPdf}
                >
                  <Download className="w-4 h-4 mr-2" />
                  {t(lang, 'complete.downloadCatalogPdf')}
                </Button>
              </CardContent>
            </Card>
          )}

          {combinedPdf && (
            <Card className="border-purple-200 bg-gradient-to-br from-purple-50/80 to-white overflow-hidden">
              <div
                className="h-48 bg-stone-100 flex items-center justify-center p-4 cursor-pointer hover:bg-stone-50 transition-colors"
                onClick={() => onPreview(combinedPdf)}
              >
                <div className="text-center">
                  <FileText className="w-12 h-12 text-purple-700/40 mx-auto mb-2" />
                  <p className="text-sm text-stone-500">{t(lang, 'complete.clickPreviewImperial')}</p>
                  <div className="mt-2 text-xs text-purple-700 font-medium bg-purple-100 px-3 py-1 rounded-full inline-block">
                    Metric + Imperial
                  </div>
                </div>
              </div>
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                    <Ruler className="w-5 h-5 text-purple-800" />
                  </div>
                  <div>
                    <h3 className="font-bold text-stone-900">{t(lang, 'complete.combinedVersion')}</h3>
                    <p className="text-xs text-stone-500">
                      {lang === 'en' ? 'Metric & imperial in one document' : 'Métrico e imperial en un documento'}
                    </p>
                  </div>
                </div>
                <Button
                  className="w-full bg-purple-800 hover:bg-purple-900 text-white"
                  onClick={() =>
                    combinedPdf && onDownload(combinedPdf, `${furnitureData.productName || 'furniture'}_combined.pdf`)
                  }
                  disabled={!combinedPdf}
                >
                  <Download className="w-4 h-4 mr-2" />
                  {t(lang, 'complete.downloadCombinedPdf')}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Summary */}
      <div className="max-w-4xl mx-auto mt-8">
        <Card className="border-stone-200">
          <CardContent className="p-6">
            <h3 className="font-bold text-stone-900 mb-4">{t(lang, 'complete.specSummary')}</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-stone-500">{t(lang, 'complete.product')}</p>
                <p className="font-semibold text-stone-900">{furnitureData.productName}</p>
              </div>
              <div>
                <p className="text-stone-500">{t(lang, 'complete.brand')}</p>
                <p className="font-semibold text-stone-900">{furnitureData.brand}</p>
              </div>
              <div>
                <p className="text-stone-500">{t(lang, 'editing.category')}</p>
                <p className="font-semibold text-stone-900">{furnitureData.category}</p>
              </div>
              <div>
                <p className="text-stone-500">{t(lang, 'complete.reference')}</p>
                <p className="font-semibold text-stone-900">{furnitureData.referenceNumber}</p>
              </div>
              <div>
                <p className="text-stone-500">{t(lang, 'editing.height')}</p>
                <p className="font-semibold text-stone-900">
                  {furnitureData.dimensions.height.feet}' {furnitureData.dimensions.height.inches}" (
                  {feetInchesToMeters(furnitureData.dimensions.height.feet, furnitureData.dimensions.height.inches)} m)
                </p>
              </div>
              <div>
                <p className="text-stone-500">{t(lang, 'editing.width')}</p>
                <p className="font-semibold text-stone-900">
                  {furnitureData.dimensions.width.feet}' {furnitureData.dimensions.width.inches}" (
                  {feetInchesToMeters(furnitureData.dimensions.width.feet, furnitureData.dimensions.width.inches)} m)
                </p>
              </div>
              <div>
                <p className="text-stone-500">{t(lang, 'editing.depth')}</p>
                <p className="font-semibold text-stone-900">
                  {furnitureData.dimensions.depth.feet}' {furnitureData.dimensions.depth.inches}" (
                  {feetInchesToMeters(furnitureData.dimensions.depth.feet, furnitureData.dimensions.depth.inches)} m)
                </p>
              </div>
              <div>
                <p className="text-stone-500">{t(lang, 'editing.materials')}</p>
                <p className="font-semibold text-stone-900">
                  {furnitureData.materials.join(', ') || t(lang, 'complete.none')}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
